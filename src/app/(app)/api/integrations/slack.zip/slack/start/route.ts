import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { SESSION_COOKIE } from "@/lib/auth/session";
import { getMeFromSessionId } from "@/modules/auth/service/auth.service";
import {
  buildAuthorizeUrl,
  SLACK_OAUTH_STATE_COOKIE,
  SLACK_OAUTH_RETURNTO_COOKIE,
} from "@/modules/integrations/slack/services/slackAuth.service";

function safeReturnTo(raw: string | null) {
  if (!raw) return "/settings/integrations";
  if (raw.startsWith("/")) return raw;
  try {
    const u = new URL(raw);
    return `${u.pathname}${u.search}`;
  } catch {
    return "/settings/integrations";
  }
}

export async function GET(req: NextRequest) {
  const origin = (process.env.APP_PUBLIC_ORIGIN ?? req.nextUrl.origin).replace(
    /\/$/,
    "",
  );
  const secure = origin.startsWith("https://");

  const sessionId = req.cookies.get(SESSION_COOKIE)?.value;
  if (!sessionId) return NextResponse.redirect(new URL("/login", origin));

  const user = await getMeFromSessionId(sessionId);
  if (!user) return NextResponse.redirect(new URL("/login", origin));

  const url = new URL(req.url);
  const returnTo = safeReturnTo(url.searchParams.get("returnTo"));

  const state = randomUUID();
  const authorizeUrl = buildAuthorizeUrl({ state });

  const res = NextResponse.redirect(authorizeUrl);

  res.cookies.set(SLACK_OAUTH_STATE_COOKIE, state, {
    httpOnly: true,
    sameSite: "lax",
    secure,
    path: "/",
    maxAge: 10 * 60,
  });

  res.cookies.set(SLACK_OAUTH_RETURNTO_COOKIE, returnTo, {
    httpOnly: true,
    sameSite: "lax",
    secure,
    path: "/",
    maxAge: 10 * 60,
  });

  return res;
}
